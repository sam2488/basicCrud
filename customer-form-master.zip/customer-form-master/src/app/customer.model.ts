export class CustomerModel {
  FirstName: string;
  LastName: string;
  Address1: string;
  Address2: string;
  City: string;
  State: string;
  Country: string;
  ZipCode: string;
  Phone: string;
  EmailID: string;
}
