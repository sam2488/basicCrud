import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  endpoint = environment.endpoint;

  constructor(private http: HttpClient) { }

  add(numbers) {
    console.log(numbers);
    return this.http.post<any>(this.endpoint + '/add', numbers);
  }

}
