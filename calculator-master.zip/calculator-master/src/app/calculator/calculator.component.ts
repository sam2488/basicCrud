import {Component, OnInit} from '@angular/core';
import {CalculatorService} from '../service/calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.less']
})
export class CalculatorComponent implements OnInit {

  no1 = 0;
  no2 = 0;
  no3 = 0;
  numbers;
  sum = 0;
  show;

  constructor(private calculatorService: CalculatorService) {
  }

  ngOnInit() {
  }

  add() {
    this.numbers = {
      'no1': this.no1,
      'no2': this.no2,
      'no3': this.no3
    };
    console.log(this.numbers);
    this.calculatorService.add(this.numbers).subscribe((result) => {
      this.sum = result;
      console.log(this.sum);
      this.show = true;
    });
  }

  reset() {
    this.no1 = 0;
    this.no2 = 0;
    this.no3 = 0;
    this.show = false;
  }
}
